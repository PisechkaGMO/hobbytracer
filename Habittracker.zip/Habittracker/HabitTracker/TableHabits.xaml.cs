﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HabitTracker
{
    /// <summary>
    /// Логика взаимодействия для TableHabits.xaml
    /// </summary>
    public partial class TableHabits : Window
    {
        public TableHabits()
        {
            InitializeComponent();
        }

        private void btnAddHabit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnSaveHabit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnDeleteHabit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
